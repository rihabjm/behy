import { Remise } from './remise';

describe('Remise', () => {
  it('should create an instance', () => {
    expect(new Remise()).toBeTruthy();
  });
});
