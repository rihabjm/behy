export class ImageModel {



}
