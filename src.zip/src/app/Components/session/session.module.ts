import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule }  from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { SessionRoutingModule } from './session-routing.module';
import { OuvrirsessionComponent } from './ouvrirsession/ouvrirsession.component';
import { SessionComponent } from './session/session.component';
import { AffichesessionComponent } from './affichesession/affichesession.component';
import { AffectparticipntComponent } from './affectparticipnt/affectparticipnt.component';
import { SessionparformationComponent } from './sessionparformation/sessionparformation.component';
import { SeancesComponent } from './seances/seances.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { BrowserModule } from '@angular/platform-browser';

@NgModule({
  declarations: [OuvrirsessionComponent, SessionComponent, AffichesessionComponent, AffectparticipntComponent,  SessionparformationComponent, SeancesComponent],
  imports: [
    CommonModule,
    SessionRoutingModule ,FormsModule, ReactiveFormsModule ,HttpClientModule ,NgbModule  ,NgMultiSelectDropDownModule.forRoot()



  ]
})
export class SessionModule { }

