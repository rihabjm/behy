import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SessionparformationComponent } from './sessionparformation.component';

describe('SessionparformationComponent', () => {
  let component: SessionparformationComponent;
  let fixture: ComponentFixture<SessionparformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SessionparformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SessionparformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
