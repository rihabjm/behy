import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supprimesalle',
  templateUrl: './supprimesalle.component.html',
  styleUrls: ['./supprimesalle.component.scss']
})
export class SupprimesalleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
