import { NgModule , ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListformateurComponent } from './listformateur/listformateur.component';
import { FormateurRoutingModule } from './formateur-routing.module';
import { AjoutformateurComponent } from './ajoutformateur/ajoutformateur.component';
import { SupprimeformateurComponent } from './supprimeformateur/supprimeformateur.component';
import { ModifierformateurComponent } from './modifierformateur/modifierformateur.component';
import { FormateurComponent } from './formateur/formateur.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule  ,FormBuilder }  from '@angular/forms';
import { DetatilsformateurComponent } from './detatilsformateur/detatilsformateur.component';
import { CalndrierformateurComponent } from './calndrierformateur/calndrierformateur.component';
import { CalendrierformateurComponent } from './calendrierformateur/calendrierformateur.component';
import { Routes, RouterModule } from '@angular/router';
import { AffecteformateurComponent } from './affecteformateur/affecteformateur.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { HttpClientModule } from '@angular/common/http';
import {MatButtonModule } from '@angular/material/button';
import {MatIconModule} from '@angular/material';
import {MatTableModule} from '@angular/material/table';
import { MatPaginatorModule , MatInputModule , MatFormFieldModule,MatRadioModule,MatNativeDateModule, NativeDateModule, MatDatepickerModule} from '@angular/material';
import {MatDialogModule} from '@angular/material/dialog';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatCardModule} from '@angular/material/card';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatSelectModule} from '@angular/material/select';
import {MatExpansionModule} from '@angular/material/expansion';
import { NavbarComponent } from '../../navbar/navbar.component';
import { SidebarComponent } from '../../sidebar/sidebar.component';
import { FooterComponent } from '../../footer/footer.component';
@NgModule({
  declarations: [NavbarComponent,SidebarComponent, FooterComponent,AjoutformateurComponent, SupprimeformateurComponent, ModifierformateurComponent, ListformateurComponent, FormateurComponent, DetatilsformateurComponent, CalndrierformateurComponent, CalendrierformateurComponent, AffecteformateurComponent ],
  imports: [
    CommonModule,MatCardModule,MatTooltipModule,MatSelectModule,
    FormateurRoutingModule ,  NativeDateModule,MatNativeDateModule ,
    NgbModule,FormsModule, MatSnackBarModule,MatExpansionModule,
     ReactiveFormsModule  ,MatRadioModule,MatDatepickerModule,
     HttpClientModule ,MatIconModule ,MatTableModule,MatPaginatorModule ,MatInputModule,
MatButtonModule ,MatFormFieldModule,MatDialogModule ,

NgMultiSelectDropDownModule.forRoot()
]
})
export class FormateurModule { }

