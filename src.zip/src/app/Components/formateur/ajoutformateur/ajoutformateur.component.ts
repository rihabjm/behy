import { Component, OnInit , ViewEncapsulation, ChangeDetectorRef , Input } from '@angular/core';
import {Formateur} from '../../../Model/Formateur';
import {FormateurService} from '../../../Service/formateur.service';
import {Specilaite} from '../../../Model/Specilaite';
import {SpecialiteService} from '../../../Service/specialite.service';
import {FormControl,FormGroup,FormBuilder ,NgForm, ReactiveFormsModule,Validators, NgControl,ValidationErrors ,FormsModule } from '@angular/forms';
import { HttpClient, HttpEventType  ,HttpResponse} from '@angular/common/http';
import {FileService} from '../../../Service/file.service';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {UploadfileService} from '../../../Service/uploadfile.service';
import { Observable } from 'rxjs';
import {MatSnackBar} from '@angular/material/snack-bar';
import {MatSnackBarModule} from '@angular/material/snack-bar';
 @Component({
  selector: 'app-ajoutformateur',
  templateUrl: './ajoutformateur.component.html',
  styleUrls: ['./ajoutformateur.component.scss']
})
export class AjoutformateurComponent implements OnInit {

  dropdownList = [];
  selectedItems = [];
   selection = [];
   message :string ;
 temp =new Array();
 specialites: Specilaite[] = new Array();
 specialiteschoisi: Specilaite[] = new Array();


constructor(private snackBar: MatSnackBar ,private uploadService : UploadfileService,   private modalService: NgbModal  , private changeDetect: ChangeDetectorRef  ,private httpClient: HttpClient , private formateurService: FormateurService, private FileService :FileService , private specialiteService :SpecialiteService   ) { }
  formateur : Formateur =new Formateur() ;
   selectedFile: File;


 id : number ;

    submitted = false;
  ngOnInit() {
   this.submitted=false;
  this.getspecialite();

}

/********************Annuler********************/
  initialiser() { this.formateur=new Formateur();}

 /***************Snackbar*************/


  /********* ajouter formateur *********/
       Ajouter(formateur :Formateur  ) {

         this.formateurService.save(this.formateur).subscribe( data => {
          this.id=data.id ;
   this.uploadService.pushFileToStoragecv(this.currentFileUpload,data.id ).subscribe(event => {
  this.selectedFiles = undefined;
    });

for(let j=0;j<this.tableaufilecertificat.length ;j++)
  {for(let i=0;i<this.tableaufilecertificat.length ;i++)
  {
   this.uploadService.pushFileToStoragecertificat(this.tableaufilecertificat[i],data.id,this.tableauspecialite[j]).subscribe(event => {
      });
}  }


 this.message="Formateur ajouté" ;
 }, ex => {
    this.message="Echec d'ajout " ;
      console.log(ex);
    });





       }



 /*****recupere cv ************/
   selectedFiles: FileList;
  currentFileUpload: File;

showFile = false;
  fileUploads: Observable<string[]>;

private   showFilesCv(enable: boolean) {
    this.showFile = enable;

    if (enable) {
      this.fileUploads = this.uploadService.getFilesCv(this.id);
    }
  }

    selectFileCV(event) {
    this.selectedFiles = event.target.files;
  }

  private upload() {

    this.currentFileUpload = this.selectedFiles.item(0);
}

/*************recupere certficat ********/
 selectedFilescertif :FileList; ;
currentFileUploadcertif :File ;
tableauspecialite :number [] =new Array();
tableaufilecertificat :File[] =new Array() ;

getspecialite()
  {
    this.specialiteService.list().subscribe((data: any) => {
    this.specialites=data ;

       });
  }

selectFileCertif(event) {
    this.selectedFilescertif = event.target.files;
  }



   sp :number ;

    private uploadcertif() {
this.tableauspecialite.push(this.sp);

    this.currentFileUploadcertif = this.selectedFilescertif.item(0);
this.tableaufilecertificat.push(this.currentFileUploadcertif);

      console.log(this.tableauspecialite);
      console.log(this.tableaufilecertificat);
}

 @Input() fileUpload: string;


}



