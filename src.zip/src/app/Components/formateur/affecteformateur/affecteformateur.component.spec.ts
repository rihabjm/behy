import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AffecteformateurComponent } from './affecteformateur.component';

describe('AffecteformateurComponent', () => {
  let component: AffecteformateurComponent;
  let fixture: ComponentFixture<AffecteformateurComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AffecteformateurComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AffecteformateurComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
