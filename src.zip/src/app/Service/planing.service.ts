import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Planing} from '../Model/Planing';
@Injectable({
  providedIn: 'root'
})
export class PlaningService {
constructor(private httpClient: HttpClient) { }

private url = Config.BASE_URL + '/planing';
  private urld = this.url + '/add';
private urlremise = this.url + '/bysession';
private urlsalleocuppe =this.url+'/getsalleoccupe' ;

  add(planing:Planing , idCategory: number,id : number,idsalle :number): Observable<object> {
    return this.httpClient.post(`${this.urld}/${idCategory}/${id}/${idsalle}`, planing);
  }
 public getplaning(id: number): Observable<any> {
    return this.httpClient.get(`${this.urlremise }/${id}`);
  }

 public getsalleoccuppe(date : Date ,id: number,idsalle :number): Observable<any> {
    return this.httpClient.get(`${this.urlsalleocuppe}/${date}/${id}/${idsalle}`);
  }

}

