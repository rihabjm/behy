import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccplateformeComponent } from './accplateforme/accplateforme.component';
import { ListformateurComponent } from './Components/formateur/listformateur/listformateur.component';
import { AuthGuard } from './auth.guard';

const routes: Routes = [
  {path: '', component: AccplateformeComponent, canActivate: [AuthGuard] , children : [
   { path: 'formateur/lister', component: ListformateurComponent },
] } ,



// { path: '', redirectTo: 'accui', pathMatch: 'full' },
{ path: 'accui', component: AccplateformeComponent },





];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
